//  WechatOpenSDK.h
//
//  Created by Wechat.
//  Copyright (c) 2012年 Tencent. All rights reserved.
//
#import <WechatOpenSDK/WXApi.h>
#import <WechatOpenSDK/WXApiObject.h>
#import <WechatOpenSDK/WechatAuthSDK.h>

